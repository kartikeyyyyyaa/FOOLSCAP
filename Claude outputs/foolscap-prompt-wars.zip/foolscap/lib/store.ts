import { getSupabase } from "./supabase";
import type { Attempt } from "./types";

const KEY = "foolscap.attempts";
const MAX_LOCAL = 400;

/* ------------------------------------------------------------------ *
 * Local storage. Always available, and the fallback for everything.
 * ------------------------------------------------------------------ */

export function loadLocal(): Attempt[] {
  try {
    const raw = window.localStorage.getItem(KEY);
    const parsed: unknown = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? (parsed as Attempt[]) : [];
  } catch {
    return [];
  }
}

export function saveLocal(attempts: Attempt[]): void {
  try {
    window.localStorage.setItem(KEY, JSON.stringify(attempts.slice(0, MAX_LOCAL)));
  } catch {
    // Private windows and blocked site data land here. Progress tracking is a
    // convenience, so losing it must never break the run.
  }
}

/* ------------------------------------------------------------------ *
 * Supabase row mapping
 * ------------------------------------------------------------------ */

interface AttemptRow {
  id: string;
  topic_title: string;
  subject: string | null;
  right_count: number;
  total_count: number;
  section_stats: Attempt["sectionStats"] | null;
  created_at: string;
}

function fromRow(row: AttemptRow): Attempt {
  const total = row.total_count || 0;
  return {
    id: row.id,
    topicTitle: row.topic_title,
    subject: row.subject ?? "",
    right: row.right_count,
    total,
    ratio: total ? row.right_count / total : 0,
    sectionStats: row.section_stats ?? {},
    createdAt: new Date(row.created_at).getTime(),
  };
}

/* ------------------------------------------------------------------ *
 * The public surface. Every call degrades to local on any failure.
 * ------------------------------------------------------------------ */

export async function listAttempts(userId: string | null): Promise<Attempt[]> {
  const supabase = getSupabase();
  if (!supabase || !userId) return loadLocal();

  const { data, error } = await supabase
    .from("attempts")
    .select("id, topic_title, subject, right_count, total_count, section_stats, created_at")
    .order("created_at", { ascending: false })
    .limit(MAX_LOCAL);

  if (error || !data) return loadLocal();
  return (data as AttemptRow[]).map(fromRow);
}

export async function saveAttempt(userId: string | null, attempt: Attempt): Promise<void> {
  const supabase = getSupabase();

  if (!supabase || !userId) {
    saveLocal([attempt, ...loadLocal()]);
    return;
  }

  const { error } = await supabase.from("attempts").insert({
    user_id: userId,
    topic_title: attempt.topicTitle,
    subject: attempt.subject,
    right_count: attempt.right,
    total_count: attempt.total,
    section_stats: attempt.sectionStats,
    created_at: new Date(attempt.createdAt).toISOString(),
  });

  // A failed write still keeps the attempt on this device rather than losing it.
  if (error) saveLocal([attempt, ...loadLocal()]);
}

export async function clearAttempts(userId: string | null): Promise<void> {
  const supabase = getSupabase();
  saveLocal([]);
  if (!supabase || !userId) return;
  await supabase.from("attempts").delete().eq("user_id", userId);
}

/**
 * Moves anything recorded before signing in into the account, so a student who
 * tries the tool and then creates an account does not lose their history.
 */
export async function mergeLocalInto(userId: string): Promise<void> {
  const supabase = getSupabase();
  const local = loadLocal();
  if (!supabase || local.length === 0) return;

  const { error } = await supabase.from("attempts").insert(
    local.map((a) => ({
      user_id: userId,
      topic_title: a.topicTitle,
      subject: a.subject,
      right_count: a.right,
      total_count: a.total,
      section_stats: a.sectionStats,
      created_at: new Date(a.createdAt).toISOString(),
    })),
  );

  if (!error) saveLocal([]);
}
