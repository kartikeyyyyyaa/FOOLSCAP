import { GoogleGenAI } from "@google/genai";
import { NextResponse } from "next/server";
import { MAX_SOURCE_CHARS, SHEET_SCHEMA, buildPrompt } from "@/lib/prompt";
import type { Depth, GenerateResponse, RevisionSheet } from "@/lib/types";

export const runtime = "nodejs";
export const maxDuration = 60;

const DEFAULT_MODEL = "gemini-2.5-flash";

function fail(error: string, status: number) {
  return NextResponse.json<GenerateResponse>({ error }, { status });
}

/**
 * Drops anything malformed rather than letting a half-built question reach the
 * UI, where it would render as an unanswerable card.
 */
function sanitise(sheet: RevisionSheet): RevisionSheet {
  const sections = (sheet.sections ?? []).filter((s) => s?.heading && Array.isArray(s.points));
  const headings = new Set(sections.map((s) => s.heading));

  return {
    subject: sheet.subject ?? "",
    title: sheet.title ?? "",
    overview: sheet.overview ?? "",
    sections,
    concepts: (sheet.concepts ?? []).filter((c) => c?.term && c?.definition),
    memorize: (sheet.memorize ?? []).filter(Boolean),
    traps: (sheet.traps ?? []).filter(Boolean),
    quiz: (sheet.quiz ?? [])
      .filter(
        (q) =>
          q?.question &&
          Array.isArray(q.options) &&
          q.options.length >= 2 &&
          typeof q.answerIndex === "number" &&
          q.answerIndex >= 0 &&
          q.answerIndex < q.options.length,
      )
      // A `tests` value that does not name a real section would send the
      // debrief somewhere the student cannot go, so it is normalised here.
      .map((q) => ({ ...q, tests: headings.has(q.tests) ? q.tests : (sections[0]?.heading ?? "General") })),
  };
}

export async function POST(request: Request) {
  const apiKey = process.env.GEMINI_API_KEY ?? process.env.GOOGLE_API_KEY;
  if (!apiKey) {
    return fail(
      "The server has no GEMINI_API_KEY set. Copy .env.example to .env.local and add a key from Google AI Studio.",
      500,
    );
  }

  let body: { source?: string; subject?: string; depth?: Depth; count?: number };
  try {
    body = await request.json();
  } catch {
    return fail("The request body was not valid JSON.", 400);
  }

  const source = (body.source ?? "").trim().slice(0, MAX_SOURCE_CHARS);
  const subject = (body.subject ?? "").trim().slice(0, 120);
  const depth: Depth = body.depth === "thorough" ? "thorough" : "quick";
  const count = body.count === 10 ? 10 : 5;

  if ((source.match(/\S+/g) ?? []).length < 40) {
    return fail("There is not enough text to revise from. Send at least a few paragraphs.", 400);
  }

  const ai = new GoogleGenAI({ apiKey });

  try {
    const response = await ai.models.generateContent({
      model: process.env.GEMINI_MODEL || DEFAULT_MODEL,
      contents: buildPrompt(source, subject, depth, count),
      config: {
        responseMimeType: "application/json",
        responseSchema: SHEET_SCHEMA,
        temperature: 0.4,
        maxOutputTokens: depth === "thorough" ? 8192 : 4096,
      },
    });

    const raw = response.text;
    if (!raw) {
      return fail("Gemini returned an empty response. Try again.", 502);
    }

    let parsed: RevisionSheet;
    try {
      parsed = JSON.parse(raw) as RevisionSheet;
    } catch {
      return fail("Gemini returned output this app could not read. Try again.", 502);
    }

    const sheet = sanitise(parsed);
    if (!sheet.title || sheet.quiz.length === 0) {
      return fail("The revision sheet came back incomplete. Try again.", 502);
    }

    return NextResponse.json<GenerateResponse>({ sheet });
  } catch (error) {
    const message = error instanceof Error ? error.message : "";

    if (/API key|API_KEY_INVALID|permission/i.test(message)) {
      return fail("The Gemini API key was rejected. Check GEMINI_API_KEY.", 401);
    }
    if (/quota|RESOURCE_EXHAUSTED|429/i.test(message)) {
      return fail("Gemini rate limited this key. Wait about a minute and try again.", 429);
    }
    if (/overload|UNAVAILABLE|503/i.test(message)) {
      return fail("Gemini is busy right now. Try again shortly.", 503);
    }

    return fail(`The Gemini call failed: ${message || "unknown error"}`, 502);
  }
}
